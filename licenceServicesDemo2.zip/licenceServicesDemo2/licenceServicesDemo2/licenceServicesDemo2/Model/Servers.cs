﻿using System;
using System.Collections.Generic;
using System.Text;

namespace licenceServicesDemo2.Model
{
    public class Servers
    {
        public int ServerID { get; set; }

        public string IP { get; set; }

        public int Used { get; set; }

        public int Avaiable { get; set; }

        //public Servers()
        //{
        //    LoadData();
        //}

        //public void LoadData()
        //{
        //    List<Servers> Temp = new List<Servers>();

        //    Temp.Add(new Servers() { ServerID = 1, IP = "10.100.12.1", Used = 15, Avaiable = 52 });
        //    Temp.Add(new Servers() { ServerID = 2, IP = "10.100.12.2", Used = 25, Avaiable = 42 });
        //    Temp.Add(new Servers() { ServerID = 3, IP = "10.100.12.3", Used = 35, Avaiable = 32 });
        //    Temp.Add(new Servers() { ServerID = 4, IP = "10.100.12.4", Used = 45, Avaiable = 22 });
        //    Temp.Add(new Servers() { ServerID = 5, IP = "10.100.12.5", Used = 55, Avaiable = 12 });
        //    Temp.Add(new Servers() { ServerID = 6, IP = "10.100.12.6", Used = 65, Avaiable = 25 });
        //}
    }

    
}
